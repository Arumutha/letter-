LOVE LETTER WEBSITE - FIXED VERSION

Files:
  index.html
  style.css
  script.js

Keep all 3 files in the same folder.

To run:
1. Extract the ZIP.
2. Open the folder.
3. Double-click index.html.

No backend or Node.js is required.

Letter:
- Write/Edit/Save/Clear works.
- Draft auto-saves in LocalStorage.
- Saved letter remains after refresh.

Memories:
- Click Edit on any card.

Photos:
- Local image files are stored in IndexedDB.
- Image URLs are also supported.

Voice:
- Select an audio file.
- It is stored locally with IndexedDB.

Note:
Browser storage is device/browser specific. Clearing site data can remove saved local content.
