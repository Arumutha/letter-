const LETTER_KEY = "loveLetter";
const MEMORIES_KEY = "loveMemories";
const SURPRISE_KEY = "loveSurprise";
const DRAFT_KEY = "loveLetterDraft";

const defaultLetter = {
  name: "My Favourite Person",
  body: "Write your little love letter here... ❤️",
  signature: "Forever yours"
};

const defaultMemories = [
  { title: "The Beginning", text: "Where our little story started..." },
  { title: "Our First Memory", text: "A memory I will always keep close." },
  { title: "The Moment I Knew", text: "That tiny moment when you became special." },
  { title: "My Favourite Memory", text: "One memory I could relive forever." },
  { title: "Forever & Always", text: "A little promise for all the days ahead." }
];

const defaultSurprise =
  "If I had to choose again, in every lifetime, I would still choose you. ❤️";

const $ = id => document.getElementById(id);

function readJSON(key, fallback) {
  try {
    const value = localStorage.getItem(key);
    return value ? JSON.parse(value) : fallback;
  } catch {
    return fallback;
  }
}

function writeJSON(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

/* ---------------- Letter ---------------- */

let letter = readJSON(LETTER_KEY, defaultLetter);

function renderLetter() {
  $("displayName").textContent = letter.name || defaultLetter.name;
  $("displayLetter").textContent = letter.body || "";
  $("displaySignature").textContent =
    letter.signature || defaultLetter.signature;

  const hasSavedLetter = localStorage.getItem(LETTER_KEY) !== null;

  $("editLetterBtn").classList.toggle("hidden", !hasSavedLetter);
  $("clearLetterBtn").classList.toggle("hidden", !hasSavedLetter);

  $("writeLetterBtn").textContent = hasSavedLetter
    ? "✍️ Rewrite My Letter"
    : "✍️ Write My Letter";
}

function openLetterEditor() {
  const draft = readJSON(DRAFT_KEY, null);
  const source = draft || letter;

  $("nameInput").value = source.name || "";
  $("letterInput").textContent = source.body || "";
  $("signatureInput").value = source.signature || "";

  updateCharacterCount();
  $("letterEditor").classList.remove("hidden");

  $("letterEditor").scrollIntoView({
    behavior: "smooth",
    block: "center"
  });

  $("letterInput").focus();
}

function closeLetterEditor() {
  $("letterEditor").classList.add("hidden");
}

function updateCharacterCount() {
  $("charCount").textContent =
    `${$("letterInput").textContent.length} characters`;
}

function saveDraft() {
  writeJSON(DRAFT_KEY, {
    name: $("nameInput").value,
    body: $("letterInput").textContent,
    signature: $("signatureInput").value
  });
}

function saveLetter() {
  letter = {
    name: $("nameInput").value.trim() || defaultLetter.name,
    body: $("letterInput").textContent.trim(),
    signature:
      $("signatureInput").value.trim() || defaultLetter.signature
  };

  if (!letter.body) {
    alert("Please write something in your letter first. 💗");
    $("letterInput").focus();
    return;
  }

  writeJSON(LETTER_KEY, letter);
  localStorage.removeItem(DRAFT_KEY);

  renderLetter();
  closeLetterEditor();

  $("saveMessage").textContent =
    "Your little piece of love has been saved 💕";

  setTimeout(() => {
    $("saveMessage").textContent = "";
  }, 3500);
}

$("writeLetterBtn").addEventListener("click", openLetterEditor);
$("editLetterBtn").addEventListener("click", openLetterEditor);
$("closeEditorBtn").addEventListener("click", closeLetterEditor);
$("closeEditorBtn2").addEventListener("click", closeLetterEditor);
$("saveLetterBtn").addEventListener("click", saveLetter);

$("nameInput").addEventListener("input", saveDraft);
$("signatureInput").addEventListener("input", saveDraft);

$("letterInput").addEventListener("input", () => {
  updateCharacterCount();
  saveDraft();
});

$("clearLetterBtn").addEventListener("click", () => {
  if (!confirm("Are you sure you want to clear your saved love letter?")) {
    return;
  }

  localStorage.removeItem(LETTER_KEY);
  localStorage.removeItem(DRAFT_KEY);
  letter = { ...defaultLetter };

  renderLetter();
  $("saveMessage").textContent = "Your saved letter has been cleared.";

  setTimeout(() => {
    $("saveMessage").textContent = "";
  }, 3000);
});

/* Formatting toolbar */

document.querySelectorAll(".toolbar button").forEach(button => {
  button.addEventListener("click", () => {
    const command = button.dataset.command;

    $("letterInput").focus();

    if (command === "bold") {
      document.execCommand("bold");
    } else if (command === "italic") {
      document.execCommand("italic");
    } else if (command === "heart") {
      insertAtCursor(" ❤️ ");
    } else if (command === "break") {
      document.execCommand("insertHTML", false, "<br>");
    }

    updateCharacterCount();
    saveDraft();
  });
});

function insertAtCursor(text) {
  const selection = window.getSelection();

  if (!selection || selection.rangeCount === 0) {
    $("letterInput").append(document.createTextNode(text));
    return;
  }

  const range = selection.getRangeAt(0);

  if (!$("letterInput").contains(range.commonAncestorContainer)) {
    $("letterInput").append(document.createTextNode(text));
    return;
  }

  range.deleteContents();
  range.insertNode(document.createTextNode(text));
  range.collapse(false);

  selection.removeAllRanges();
  selection.addRange(range);
}

/* Smooth navigation */

document.querySelectorAll("[data-scroll]").forEach(button => {
  button.addEventListener("click", () => {
    const target = document.querySelector(button.dataset.scroll);

    if (target) {
      target.scrollIntoView({ behavior: "smooth" });
    }
  });
});

/* ---------------- Memories ---------------- */

let memories = readJSON(MEMORIES_KEY, defaultMemories);

function renderMemories() {
  const grid = $("memoryGrid");
  grid.innerHTML = "";

  memories.forEach((memory, index) => {
    const card = document.createElement("article");
    card.className = "memory-card";

    const title = document.createElement("h3");
    title.textContent = memory.title;

    const text = document.createElement("p");
    text.textContent = memory.text;

    const edit = document.createElement("button");
    edit.className = "small-btn";
    edit.textContent = "✏️ Edit";

    edit.addEventListener("click", () => {
      const titleValue = prompt("Memory title:", memory.title);
      if (titleValue === null) return;

      const textValue = prompt("Memory text:", memory.text);
      if (textValue === null) return;

      memories[index] = {
        title: titleValue.trim() || memory.title,
        text: textValue.trim() || memory.text
      };

      writeJSON(MEMORIES_KEY, memories);
      renderMemories();
    });

    card.append(title, text, edit);
    grid.appendChild(card);
  });
}

/* ---------------- IndexedDB for photos/audio ---------------- */

let db = null;

function openDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("LoveLetterMedia", 1);

    request.onupgradeneeded = event => {
      const database = event.target.result;

      if (!database.objectStoreNames.contains("photos")) {
        database.createObjectStore("photos", {
          keyPath: "id",
          autoIncrement: true
        });
      }

      if (!database.objectStoreNames.contains("audio")) {
        database.createObjectStore("audio", {
          keyPath: "id"
        });
      }
    };

    request.onsuccess = event => {
      db = event.target.result;
      resolve();
    };

    request.onerror = () => reject(request.error);
  });
}

function dbRequest(storeName, mode, operation) {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, mode);
    const store = transaction.objectStore(storeName);
    const request = operation(store);

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

/* Photos */

async function getPhotos() {
  return dbRequest("photos", "readonly", store => store.getAll());
}

async function addLocalPhoto(file) {
  await dbRequest("photos", "readwrite", store =>
    store.add({
      file,
      caption: file.name.replace(/\.[^/.]+$/, "")
    })
  );

  renderPhotos();
}

async function addUrlPhoto(url, caption) {
  await dbRequest("photos", "readwrite", store =>
    store.add({
      url,
      caption: caption || "A little memory ♡"
    })
  );

  renderPhotos();
}

async function deletePhoto(id) {
  await dbRequest("photos", "readwrite", store => store.delete(id));
  renderPhotos();
}

async function renderPhotos() {
  const grid = $("photoGrid");
  grid.innerHTML = "";

  if (!db) return;

  const photos = await getPhotos();

  photos.forEach((photo, index) => {
    const figure = document.createElement("figure");
    figure.className = "photo-card";
    figure.style.setProperty(
      "--rotation",
      `${index % 2 === 0 ? -1.5 : 1.5}deg`
    );

    const image = document.createElement("img");
    image.alt = photo.caption || "Our memory";

    if (photo.file) {
      image.src = URL.createObjectURL(photo.file);
    } else {
      image.src = photo.url;
    }

    const caption = document.createElement("figcaption");
    caption.textContent = photo.caption || "A little memory ♡";

    const deleteButton = document.createElement("button");
    deleteButton.className = "delete-photo";
    deleteButton.textContent = "×";
    deleteButton.title = "Delete photo";

    deleteButton.addEventListener("click", () => {
      if (confirm("Remove this photo?")) {
        deletePhoto(photo.id);
      }
    });

    figure.append(image, caption, deleteButton);
    grid.appendChild(figure);
  });
}

$("photoInput").addEventListener("change", async event => {
  for (const file of event.target.files) {
    await addLocalPhoto(file);
  }

  event.target.value = "";
});

$("addPhotoUrlBtn").addEventListener("click", async () => {
  const url = $("photoUrlInput").value.trim();
  const caption = $("photoCaptionInput").value.trim();

  if (!url) {
    alert("Please paste an image URL.");
    return;
  }

  await addUrlPhoto(url, caption);

  $("photoUrlInput").value = "";
  $("photoCaptionInput").value = "";
});

/* ---------------- Voice note ---------------- */

async function renderAudio() {
  if (!db) return;

  const audio = await dbRequest("audio", "readonly", store =>
    store.get("main")
  );

  if (!audio) {
    $("audioPlayer").classList.add("hidden");
    $("removeAudioBtn").classList.add("hidden");
    $("audioStatus").textContent =
      "Choose an audio recording from your device.";
    return;
  }

  $("audioPlayer").src = URL.createObjectURL(audio.file);
  $("audioPlayer").classList.remove("hidden");
  $("removeAudioBtn").classList.remove("hidden");
  $("audioStatus").textContent =
    "Your voice note is saved on this device. 💗";
}

$("audioInput").addEventListener("change", async event => {
  const file = event.target.files[0];

  if (file && db) {
    await dbRequest("audio", "readwrite", store =>
      store.put({ id: "main", file })
    );

    renderAudio();
  }

  event.target.value = "";
});

$("removeAudioBtn").addEventListener("click", async () => {
  if (!confirm("Remove your saved voice note?")) return;

  await dbRequest("audio", "readwrite", store =>
    store.delete("main")
  );

  renderAudio();
});

/* ---------------- Surprise ---------------- */

let surprise =
  localStorage.getItem(SURPRISE_KEY) || defaultSurprise;

function renderSurprise() {
  $("surpriseText").textContent = surprise;
  $("surpriseInput").value = surprise;
}

$("surpriseBtn").addEventListener("click", () => {
  $("surpriseMessage").classList.remove("hidden");
  createHeartBurst();
});

$("editSurpriseBtn").addEventListener("click", () => {
  $("surpriseEditor").classList.remove("hidden");
  $("surpriseInput").focus();
});

$("saveSurpriseBtn").addEventListener("click", () => {
  surprise = $("surpriseInput").value.trim() || defaultSurprise;
  localStorage.setItem(SURPRISE_KEY, surprise);
  renderSurprise();
  $("surpriseEditor").classList.add("hidden");
  $("surpriseMessage").classList.remove("hidden");
});

/* ---------------- Floating hearts ---------------- */

function createFloatingHeart() {
  const container = document.querySelector(".floating-hearts");
  const heart = document.createElement("span");

  heart.className = "heart-particle";
  heart.textContent = Math.random() > .5 ? "♡" : "✦";
  heart.style.left = `${Math.random() * 100}%`;
  heart.style.fontSize = `${12 + Math.random() * 16}px`;
  heart.style.animationDuration = `${2.5 + Math.random() * 2}s`;

  container.appendChild(heart);

  setTimeout(() => heart.remove(), 5500);
}

setInterval(createFloatingHeart, 1800);

function createHeartBurst() {
  for (let i = 0; i < 18; i++) {
    const heart = document.createElement("span");

    heart.className = "heart-particle";
    heart.textContent = i % 2 ? "♡" : "💗";
    heart.style.left = `${45 + Math.random() * 10}%`;
    heart.style.bottom = `${35 + Math.random() * 20}%`;
    heart.style.animationDuration = `${1.5 + Math.random()}s`;

    document.querySelector(".floating-hearts").appendChild(heart);

    setTimeout(() => heart.remove(), 3000);
  }
}

/* ---------------- Start ---------------- */

renderLetter();
renderMemories();
renderSurprise();

openDatabase()
  .then(() => {
    renderPhotos();
    renderAudio();
  })
  .catch(error => {
    console.error("IndexedDB error:", error);
    $("audioStatus").textContent =
      "Local media storage is unavailable in this browser. Letters still work normally.";
  });
